﻿using BankManagementSystem.Models;
using BankManagementSystem.Repositories;

namespace BankManagementSystem.Tests
{
    public class BankRepositoryTests
    {
        private BankRepository _bankRepository;

        [SetUp]
        public void Setup()
        {
            _bankRepository = new BankRepository();
        }

        [Test]
        public void AddBank_ShouldAddBankToList()
        {
            var bank = new Bank("123", "Test Bank", "Active", "456");
            _bankRepository.AddBank(bank);

            var result = _bankRepository.GetBankByCode("123");

            Assert.IsNotNull(result);
            Assert.AreEqual("Test Bank", result.BankName);
        }

        [Test]
        public void GetBankByCode_ShouldReturnCorrectBank()
        {
            var bank1 = new Bank("123", "Test Bank 1", "Active", "456");
            var bank2 = new Bank("789", "Test Bank 2", "Inactive", "101");

            _bankRepository.AddBank(bank1);
            _bankRepository.AddBank(bank2);

            var result = _bankRepository.GetBankByCode("789");

            Assert.IsNotNull(result);
            Assert.AreEqual("Test Bank 2", result.BankName);
        }

        [Test]
        public void GetBankByCode_ShouldReturnNullIfBankNotFound()
        {
            var result = _bankRepository.GetBankByCode("999");

            Assert.IsNull(result);
        }
    }
}
